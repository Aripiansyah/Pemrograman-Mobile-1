package com.example.pancipintar;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityLogin extends AppCompatActivity {
    private EditText txtEmail, txtPass;
    private Button btnLogin;
    private TextView toRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Ganti ini dengan nama XML kamu jika berbeda

        // Inisialisasi view
        txtEmail = findViewById(R.id.txtEmail);
        txtPass = findViewById(R.id.txtPass);
        btnLogin = findViewById(R.id.btnLogin);
        toRegister = findViewById(R.id.toRegister);

        // Aksi tombol login
        btnLogin.setOnClickListener(v -> {
            String email = txtEmail.getText().toString().trim();
            String password = txtPass.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email dan password harus diisi", Toast.LENGTH_SHORT).show();
            } else {
                // Proses login bisa dihubungkan ke backend / firebase / validasi lokal
                Toast.makeText(this, "Login berhasil (dummy)", Toast.LENGTH_SHORT).show();
            }
        });

        // Aksi ketika user klik "Buat Akun Baru"
        toRegister.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityLogin.this, ActivityRegist.class); // pastikan RegisterActivity sudah ada
            startActivity(intent);
        });
    }
}
