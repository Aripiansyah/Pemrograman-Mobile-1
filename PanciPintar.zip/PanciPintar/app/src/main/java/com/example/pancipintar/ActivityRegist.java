package com.example.pancipintar;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityRegist extends AppCompatActivity {

    private EditText txtUserRegis, txtEmailRegis, txtPassRegis, txtConfirmPassRegis;
    private Button btnRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regis); // Pastikan nama XML sesuai

        // Inisialisasi view
        txtUserRegis = findViewById(R.id.txtUserRegis);
        txtEmailRegis = findViewById(R.id.txtEmailRegis);
        txtPassRegis = findViewById(R.id.txtPassRegis);
        txtConfirmPassRegis = findViewById(R.id.txtConfirmPassRegis);
        btnRegis = findViewById(R.id.btnRegis);

        // Aksi tombol Register
        btnRegis.setOnClickListener(v -> {
            String username = txtUserRegis.getText().toString().trim();
            String email = txtEmailRegis.getText().toString().trim();
            String password = txtPassRegis.getText().toString().trim();
            String confirmPassword = txtConfirmPassRegis.getText().toString().trim();

            if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Semua kolom wajib diisi", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Password tidak cocok", Toast.LENGTH_SHORT).show();
            } else {
                // Proses registrasi (dummy sementara)
                Toast.makeText(this, "Registrasi berhasil (dummy)", Toast.LENGTH_SHORT).show();
                // Di sini kamu bisa lanjut ke LoginActivity atau simpan data
                finish(); // balik ke activity sebelumnya
            }
        });
    }
}
